!function ($) {
  $(function(){	
  	$(".collapse").collapse()
  
    // make code pretty
    window.prettyPrint && prettyPrint()
})
}(window.jQuery)