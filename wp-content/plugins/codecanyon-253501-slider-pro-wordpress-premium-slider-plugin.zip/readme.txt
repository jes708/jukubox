Thank you for purchasing this item!

When you install the plugin, you only have to upload the slider-pro.zip file.
Please see the documentation file for instructions on how to use the plugin.
The 'examples' folder contains several examples that you can use as a reference.
The 'skins_src' folder contains the layered PSD or PNG files used for the skins.

Thanks again for purchasing my item and feel free to browse my portfolio on CodeCanyon for other awesome items :)

http://codecanyon.net/user/bqworks