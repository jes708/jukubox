All you have to do is import these XML files and they will appear in your Slider PRO installation. 
The instructions for importing sliders can be found in the documentation.
After you import a slider, you will need to replace the existing image paths with your own.